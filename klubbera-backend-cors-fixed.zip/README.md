# Klubbera – testmail-backend

Detta är en liten Vercel-backend för Klubberas testkassa.
Den skickar INTE riktiga produktorder eller betalningar. Den skickar bara ett testmejl via Resend.

## 1. Installera
```bash
npm install
```

## 2. Lägg in hemliga miljövariabler i Vercel
- `RESEND_API_KEY` = din Resend API-nyckel
- `FROM_EMAIL` = en avsändaradress som Resend tillåter

Lägg aldrig API-nyckeln i HTML/JavaScript som körs i webbläsaren.

## 3. Publicera
Importera projektet i Vercel och deploya.

## 4. Endpoint
POST `/api/send-order`

Exempel på JSON:
```json
{
  "customer": {
    "name": "Amin",
    "email": "din@email.se",
    "address": "Testgatan 1, Stockholm"
  },
  "orderNumber": "KL-123456",
  "total": 149,
  "items": [
    {
      "name": "Klubbera Club Ball #5",
      "price": 149,
      "qty": 1,
      "options": {
        "team": "IFK Tumba P2011 Blå",
        "number": "07"
      }
    }
  ]
}
```

## Viktigt
Detta är endast för test. Innan riktig försäljning behöver bland annat betalning, orderdatabas, moms, köpvillkor, integritet/GDPR, lager och riktig fraktlösning byggas in.
